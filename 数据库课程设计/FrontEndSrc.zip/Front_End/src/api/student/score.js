import * as courseApi from "./course";

export const list = () => courseApi.list();
