let Config = {};

Config.backEndUrl = "http://139.9.143.161:8080/api/v1";

export default Config;
