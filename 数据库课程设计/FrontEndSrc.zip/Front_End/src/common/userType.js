let UserType = {};

UserType.student = 1;
UserType.teacher = 2;
UserType.admin = 3;

export default UserType;
