# 读我

## 初始化工具

`./tools`目录下的工具为初始化数据库的工具，
具体参数在`init_conf.ini`内设置，
目前可执行文件只有arm64版本darwin架构，其他环境需要有go环境进行编译运行。
>TODO: 编译windows amd64版本可执行文件