module.exports = {
  lintOnSave: false,
};
